const app = require('app');  // Module to control application life.
const Menu = require('menu');
const menubar = require('menubar');
const mb = menubar({width: 150, height: 82, preloadWindow:true, icon: __dirname+'/img/icon/iconTemplate.png'});


mb.on('ready', function ready () {

  var template = [{
    label: "Application",
    submenu: [
      { label: "About Application", selector: "orderFrontStandardAboutPanel:" },
      { type: "separator" },
      { label: "Quit", accelerator: "Command+Q", click: function() { app.quit(); }}
    ]}, {
    label: "Edit",
    submenu: [
      { label: "Undo", accelerator: "CmdOrCtrl+Z", selector: "undo:" },
      { label: "Redo", accelerator: "Shift+CmdOrCtrl+Z", selector: "redo:" },
      { type: "separator" },
      { label: "Cut", accelerator: "CmdOrCtrl+X", selector: "cut:" },
      { label: "Copy", accelerator: "CmdOrCtrl+C", selector: "copy:" },
      { label: "Paste", accelerator: "CmdOrCtrl+V", selector: "paste:" },
      { label: "Select All", accelerator: "CmdOrCtrl+A", selector: "selectAll:" }
    ]}
  ];

  // mb.window.openDevTools(); //uncomment to view dev tools

  Menu.setApplicationMenu(Menu.buildFromTemplate(template));

})


